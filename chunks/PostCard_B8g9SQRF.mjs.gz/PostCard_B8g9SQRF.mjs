import { d as createAstro, c as createComponent, m as maybeRenderHead, f as addAttribute, r as renderComponent, a as renderTemplate } from './astro/server_CxJSMMQf.mjs';
import { $ as $$Image } from './DescriptionMeta_zINpuFPu.mjs';
/* empty css                         */

const $$Astro = createAstro("https://sahilrana.in");
const $$PostCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$PostCard;
  const { title, description, image, slug } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(slug, "href")} class="blogPostCard"> ${renderComponent($$result, "Image", $$Image, { "src": image.url, "alt": image?.alt || "alt", "width": 230, "height": 70 })} <div class="content"> <h2 class="title"${addAttribute(slug, "id")}>${title}</h2> <p class="description">${description}</p> <!-- {
      pubDate && (
        <div class="meta">
          <span>{formatDate(pubDate)}</span>
        </div>
      )
    } --> </div> </a>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Blog/PostCard.astro", void 0);

export { $$PostCard as $ };
