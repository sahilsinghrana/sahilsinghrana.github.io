import { t as $$, c as $$Github } from './DescriptionMeta_zINpuFPu.mjs';
import { c as createComponent, d as createAstro, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from './astro/server_CxJSMMQf.mjs';

const $$Astro$2 = createAstro("https://sahilrana.in");
const $$ExternalLink = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ExternalLink;
  return renderTemplate`${renderComponent($$result, "Layout", $$, { "iconName": "external-link", ...Astro2.props }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<path d="M15 3h6v6"></path> <path d="M10 14 21 3"></path> <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/node_modules/lucide-astro/dist/ExternalLink.astro", void 0);

const $$Astro$1 = createAstro("https://sahilrana.in");
const $$Package = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Package;
  return renderTemplate`${renderComponent($$result, "Layout", $$, { "iconName": "package", ...Astro2.props }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"></path> <path d="M12 22V12"></path> <polyline points="3.29 7 12 12 20.71 7"></polyline> <path d="m7.5 4.27 9 5.15"></path> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/node_modules/lucide-astro/dist/Package.astro", void 0);

const $$Astro = createAstro("https://sahilrana.in");
const $$Youtube = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Youtube;
  return renderTemplate`${renderComponent($$result, "Layout", $$, { "iconName": "youtube", ...Astro2.props }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path> <path d="m10 15 5-3-5-3z"></path> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/node_modules/lucide-astro/dist/Youtube.astro", void 0);

const iwl = new Proxy({"src":"/_astro/iwl.C3Jlr4mP.webp","width":1241,"height":1754,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/iwl.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/iwl.webp");
							return target[name];
						}
					});

const nextChat = new Proxy({"src":"/_astro/nextchat.Dqp47PgR.webp","width":1440,"height":783,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/nextchat.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/nextchat.webp");
							return target[name];
						}
					});

const esp32Car = new Proxy({"src":"/_astro/esp8266car.BtVjD8CU.webp","width":1579,"height":957,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/esp8266car.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/esp8266car.webp");
							return target[name];
						}
					});

const diziPlayer = new Proxy({"src":"/_astro/diziPlayer.t-EA4SNe.webp","width":1917,"height":902,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/diziPlayer.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/diziPlayer.webp");
							return target[name];
						}
					});

const npxNamasteSahil = new Proxy({"src":"/_astro/npxNamasteSahil.ChKkBegW.webp","width":860,"height":216,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/npxNamasteSahil.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/npxNamasteSahil.webp");
							return target[name];
						}
					});

const TicTacToeVanilla = new Proxy({"src":"/_astro/TicTacToeVanilla.CRm1JUWr.webp","width":1918,"height":912,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/TicTacToeVanilla.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/projects/TicTacToeVanilla.webp");
							return target[name];
						}
					});

const diziPlayerMeta = {
  title: "Dizi Player",
  image: diziPlayer,
  content: "Building a Music Player using React as Frontend and Fastify as backend.",
  links: [
    {
      Icon: $$Github,
      link: "https://github.com/sahilsinghrana/ranexPlayer",
      description: "Github"
    },
    {
      Icon: $$ExternalLink,
      link: "https://dizi.sahilrana.in",
      description: "Preview"
    }
  ]
};
const jsonViewerMeta = {
  title: "JSON Viewer and formatter",
  image: "https://jsonviewer.sahilrana.in/jsonviewerscreenshot.png",
  logo: "https://jsonviewer.sahilrana.in/og-image.webp",
  content: "Developed a JSON Viewer and formatter with dark mode using React.js.",
  links: [
    {
      Icon: $$Github,
      link: "https://github.com/sahilsinghrana/jsonviewer"
    },
    {
      Icon: $$ExternalLink,
      link: "https://jsonviewer.sahilrana.in"
    }
  ]
};
const projects = [
  jsonViewerMeta,
  {
    title: "Esp8266 Car",
    image: esp32Car,
    content: "Restored my old RC car using an ESP8266 microcontroller and an L293D motor driver. The car is now controlled via a web interface and features a buzzer that plays honking sounds.",
    links: [
      {
        Icon: $$Github,
        link: "https://github.com/sahilsinghrana/esp8266RCcar"
      },
      {
        Icon: $$Youtube,
        link: "https://www.youtube.com/watch?v=1qfEjHxtqjI"
      }
    ]
  },
  {
    title: "TicTacToe",
    image: TicTacToeVanilla,
    content: "Developed a Node.js package that enables users to play Tic Tac Toe against the CPU using the Min-Max algorithm.",
    links: [
      {
        Icon: $$Github,
        link: "https://github.com/sahilsinghrana/tictactoe.js"
      },
      {
        Icon: $$Package,
        link: "https://www.npmjs.com/package/@sahilsinghrana/tictactoe.js"
      },
      {
        Icon: $$ExternalLink,
        link: "https://tictactoe.sahilrana.in"
      }
    ]
  },
  diziPlayerMeta,
  {
    title: "Namaste-sahil",
    image: npxNamasteSahil,
    content: "Created an npx script that provides a personalized greeting.",
    links: [
      {
        Icon: $$Github,
        link: "https://github.com/sahilsinghrana/namaste-sahil"
      },
      {
        Icon: $$Package,
        link: "https://www.npmjs.com/package/namaste-sahil"
      }
    ]
  },
  {
    title: "Chat Application",
    image: nextChat,
    content: "Developed a chat application with Next.js for the frontend and Express.js for the backend.",
    links: [
      {
        Icon: $$ExternalLink,
        link: "https://next-chat-phi.vercel.app/"
      }
    ]
  },
  {
    title: "IWL 2021 Sponsorship Brochure",
    image: iwl,
    content: "Created the sponsorship brochure for the AIFF Indian Women's League 2021, designed for Baroda Football Academy, using Adobe InDesign.",
    links: [
      {
        Icon: $$ExternalLink,
        link: "https://sahilsinghrana.github.io/IWL-sponsorship-brochure/"
      }
    ]
  }
];

export { diziPlayerMeta as d, jsonViewerMeta as j, projects as p };
