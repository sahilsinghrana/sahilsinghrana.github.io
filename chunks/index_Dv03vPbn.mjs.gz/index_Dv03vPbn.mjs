import { d as createAstro, c as createComponent, m as maybeRenderHead, f as addAttribute, r as renderComponent, a as renderTemplate } from './astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { $ as $$Image } from './DescriptionMeta_BXu827no.mjs';
/* empty css                         */

const $$Astro = createAstro("https://sahilrana.in");
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const { title, description, image, slug } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<a class="snippetCard"${addAttribute("/blog/snippets/" + slug, "href")}> ${renderComponent($$result, "Image", $$Image, { "src": image.url, "alt": image.alt, "height": 40, "width": 40 })} <div class="desc"> <h2>${title}</h2> <p>${description}</p> </div> </a>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Blog/SnippetCard/index.astro", void 0);

export { $$Index as $ };
