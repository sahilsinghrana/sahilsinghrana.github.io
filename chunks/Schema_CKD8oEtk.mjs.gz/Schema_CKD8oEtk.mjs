import { d as createAstro, c as createComponent, a as renderTemplate, u as unescapeHTML } from './astro/server_D_OWhRQa.mjs';
import 'piccolore';
import 'clsx';

function i(n,e){return JSON.stringify(n,o,e)}var t=Object.freeze({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}),r=new RegExp(`[${Object.keys(t).join("")}]`,"g"),s=n=>t[n],o=(n,e)=>{switch(typeof e){case "object":return e===null?void 0:e;case "number":case "boolean":case "bigint":return e;case "string":return e.replace(r,s);default:{return}}};

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://sahilrana.in");
const $$Schema = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Schema;
  const { item, space } = Astro2.props;
  return renderTemplate(_a || (_a = __template(['<script type="application/ld+json">', "<\/script>"])), unescapeHTML(i(item, space)));
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/node_modules/astro-seo-schema/dist/Schema.astro", void 0);

export { $$Schema as $ };
