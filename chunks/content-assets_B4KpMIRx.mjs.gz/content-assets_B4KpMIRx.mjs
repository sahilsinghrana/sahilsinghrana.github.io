const __ASTRO_IMAGE_IMPORT_NWWmq = new Proxy({"src":"/_astro/titleImage.BM4VR-oa.webp","width":480,"height":480,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/snippets/expose-wsl-port/titleImage.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/snippets/expose-wsl-port/titleImage.webp");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1WA8Wp = new Proxy({"src":"/_astro/titleImage.D1LvK-Z0.webp","width":480,"height":480,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/snippets/improve-git-command-performance/titleImage.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/snippets/improve-git-command-performance/titleImage.webp");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZDbknN = new Proxy({"src":"/_astro/titleImage.lmNT5B6G.webp","width":480,"height":480,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/snippets/download-using-curl/titleImage.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/snippets/download-using-curl/titleImage.webp");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z29uzuQ = new Proxy({"src":"/_astro/titleImage.C6tDlRCI.webp","width":430,"height":430,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/howto/linked-list-with-generators/titleImage.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/howto/linked-list-with-generators/titleImage.webp");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_4jMii = new Proxy({"src":"/_astro/titleImage.BdIr2d-y.webp","width":480,"height":268,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/method-chaining-js/titleImage.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/method-chaining-js/titleImage.webp");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2mtCyw = new Proxy({"src":"/_astro/titleImage.Cm4j8jTc.webp","width":500,"height":281,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/howto/convert-string-to-literal/titleImage.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/howto/convert-string-to-literal/titleImage.webp");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2wrDAL = new Proxy({"src":"/_astro/titleImage.Dy4FQ2ET.webp","width":498,"height":275,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/bitwise-operators-usecase/titleImage.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/content/blog/bitwise-operators-usecase/titleImage.webp");
							return target[name];
						}
					});

const contentAssets = new Map([["./titleImage.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fsnippets%2Fexpose-wsl-port%2Findex.md", __ASTRO_IMAGE_IMPORT_NWWmq], ["./titleImage.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fsnippets%2Fimprove-git-command-performance%2Findex.md", __ASTRO_IMAGE_IMPORT_1WA8Wp], ["./titleImage.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fsnippets%2Fdownload-using-curl%2Findex.md", __ASTRO_IMAGE_IMPORT_ZDbknN], ["./titleImage.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fhowto%2Flinked-list-with-generators%2Findex.md", __ASTRO_IMAGE_IMPORT_Z29uzuQ], ["./titleImage.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmethod-chaining-js%2Findex.md", __ASTRO_IMAGE_IMPORT_4jMii], ["./titleImage.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fhowto%2Fconvert-string-to-literal%2Findex.md", __ASTRO_IMAGE_IMPORT_Z2mtCyw], ["./titleImage.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbitwise-operators-usecase%2Findex.md", __ASTRO_IMAGE_IMPORT_2wrDAL]]);

export { contentAssets as default };
