import { d as createAstro, c as createComponent, m as maybeRenderHead, r as renderComponent, a as renderTemplate } from './astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { $ as $$Breadcrumbs } from './Breadcrumbs_CbrT2omj.mjs';
/* empty css                         */
import { $ as $$Image } from './DescriptionMeta_BXu827no.mjs';

const $$Astro = createAstro("https://sahilrana.in");
const $$SectionHeaderImage = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$SectionHeaderImage;
  const { Image: propImage, title, quote, showBreadcrumbs } = Astro2.props;
  const placeHolderImagee = propImage;
  return renderTemplate`${maybeRenderHead()}<div class="sectionHeaderImageWrapper"> ${renderComponent($$result, "Image", $$Image, { "src": placeHolderImagee, "class": "sectionHeaderImage", "alt": "section header hero ", "loading": "eager" })} <div class="titleWrapper"> <h1 class="headerImageTitle">${title}</h1> <q>${quote}</q> ${showBreadcrumbs && renderTemplate`${renderComponent($$result, "Breadcrumbs", $$Breadcrumbs, { "linkTextFormat": "capitalized", "mainBemClass": "blog-breadcrumbs" })}`} </div> </div>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Image/SectionHeaderImage.astro", void 0);

export { $$SectionHeaderImage as $ };
