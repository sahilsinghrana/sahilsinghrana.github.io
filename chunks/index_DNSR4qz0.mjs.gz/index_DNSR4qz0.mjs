import { d as createAstro, c as createComponent, m as maybeRenderHead, f as addAttribute, a as renderTemplate, r as renderComponent, h as renderScript, e as renderSlot, g as renderTransition } from './astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { l as links, o as $$Title, $ as $$Image, H as Head, i as $$Index$3, j as $$DefaultMeta, k as $$GtagHeadScripts, m as $$OgMeta, n as $$DescriptionMeta } from './DescriptionMeta_BXu827no.mjs';
import 'clsx';
/* empty css                          */
/* empty css                               */

const $$Astro$1 = createAstro("https://sahilrana.in");
const $$Navlink = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Navlink;
  const { url, label } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(url, "href")}>${label}</a>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Header/Navlink.astro", void 0);

const $$NavBar = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<nav> ${renderComponent($$result, "NavLink", $$Navlink, { "url": links.about, "label": "About" })} ${renderComponent($$result, "NavLink", $$Navlink, { "url": links.contact, "label": "Contact" })} ${renderComponent($$result, "NavLink", $$Navlink, { "url": links.projects, "label": "Projects" })} ${renderComponent($$result, "NavLink", $$Navlink, { "url": links.blog, "label": "Blog" })} </nav>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Header/NavBar.astro", void 0);

const catonline = new Proxy({"src":"/_astro/catonline.vharhGJv.gif","width":250,"height":250,"format":"gif"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Header/catonline.gif";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Header/catonline.gif");
							return target[name];
						}
					});

const $$Index$2 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<header> <div class="headerContainer"> ${renderComponent($$result, "Title", $$Title, {})} ${renderComponent($$result, "Image", $$Image, { "src": catonline, "alt": "Cat", "class": "catImage", "width": 250, "height": 250 })} ${renderComponent($$result, "NavBar", $$NavBar, {})} </div> <div class="headerBottomBorder"></div> </header>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Header/index.astro", void 0);

const Moon = new Proxy({"src":"/_astro/moon.BkvQZksr.webp","width":300,"height":297,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Moon/moon.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Moon/moon.webp");
							return target[name];
						}
					});

const $$Index$1 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Moon/index.astro?astro&type=script&index=0&lang.ts")} ${renderComponent($$result, "Image", $$Image, { "src": Moon, "height": 300, "width": 310, "class": "myMoon", "alt": "Sahil's Moon." })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Moon/index.astro", void 0);

const $$Astro = createAstro("https://sahilrana.in");
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const { title, description, keywords, className } = Astro2.props;
  return renderTemplate`<html lang="en"> ${renderComponent($$result, "Head", Head, {}, { "default": ($$result2) => renderTemplate`${renderComponent($$result2, "DefaultMeta", $$DefaultMeta, {})}${renderComponent($$result2, "GtagHeadScripts", $$GtagHeadScripts, {})}${renderComponent($$result2, "OgMeta", $$OgMeta, { "title": title, "description": description })}${renderComponent($$result2, "DescriptionMeta", $$DescriptionMeta, { "title": title, "description": description, "keywords": keywords })}<title>${title}</title>` })}${maybeRenderHead()}<body> ${renderComponent($$result, "Header", $$Index$2, {})} ${renderComponent($$result, "Moon", $$Index$1, {})} <main> <div${addAttribute("content " + className, "class")}${addAttribute(renderTransition($$result, "h4jrbs7u"), "data-astro-transition-scope")}> ${renderSlot($$result, $$slots["default"])} </div> </main> ${renderComponent($$result, "Footer", $$Index$3, {})} ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/layouts/index.astro?astro&type=script&index=0&lang.ts")}</body></html>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/layouts/index.astro", "self");

export { $$Index as $ };
