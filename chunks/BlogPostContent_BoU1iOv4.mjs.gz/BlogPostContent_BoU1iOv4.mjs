import { d as createAstro, c as createComponent, r as renderComponent, b as renderHead, a as renderTemplate, e as renderSlot, f as addAttribute, m as maybeRenderHead } from './astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { $ as $$Breadcrumbs } from './Breadcrumbs_CbrT2omj.mjs';
import { $ as $$Schema } from './Schema_C8seynNl.mjs';
import { $ as $$Index } from './index_DNSR4qz0.mjs';
/* empty css                          */
import { $ as $$Image } from './DescriptionMeta_BXu827no.mjs';
import 'clsx';

const formatDate = (date) => {
  if (!date) return "";
  return date.toDateString();
};

const $$Astro = createAstro("https://sahilrana.in");
const $$BlogPost = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BlogPost;
  const { entry } = Astro2.props;
  const { data } = entry;
  const { title, image, description, tags, pubDate } = data;
  return renderTemplate`<head>${renderComponent($$result, "Schema", $$Schema, { "item": {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: title,
    description,
    mainEntityOfPage: {
      "@type": "WebPage"
    },
    author: {
      "@type": "Person",
      name: "Sahil Rana",
      url: "https://sahilrana.in"
    },
    publisher: {
      "@type": "Organization",
      name: "Sahil Rana",
      logo: {
        "@type": "ImageObject",
        url: "https://avatars.githubusercontent.com/u/48375250"
      }
    },
    datePublished: pubDate,
    dateModified: pubDate,
    keywords: tags.join(", "),
    articleSection: "Technology",
    inLanguage: "en-US"
  } })}${renderHead()}</head> ${renderComponent($$result, "Layout", $$Index, { "title": title + " | Sahil Rana", "description": description, "keywords": tags }, { "default": ($$result2) => renderTemplate` <div class="blogPostHeading"> <div class="bg"> ${renderComponent($$result2, "Image", $$Image, { "src": image.url, "alt": image.alt, "height": image.url.height || 100, "width": image.url.width || 300, "loading": "eager" })} <div class="head"> <h2><em>${title}</em></h2> ${renderComponent($$result2, "Breadcrumbs", $$Breadcrumbs, { "linkTextFormat": "capitalized", "mainBemClass": "blog-breadcrumbs" })} </div> </div> </div> ${renderSlot($$result2, $$slots["default"])} ${pubDate && renderTemplate`<div class="blogPostMeta"> <span class="pubDate">
Published On:${" "} <time${addAttribute(formatDate(pubDate), "datetime")}>${formatDate(pubDate)}</time> </span> </div>`}` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/layouts/BlogPost.astro", void 0);

const $$BlogPostContent = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<article class="blogContent"> ${renderSlot($$result, $$slots["default"])} </article>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/layouts/BlogPostContent.astro", void 0);

export { $$BlogPost as $, $$BlogPostContent as a };
