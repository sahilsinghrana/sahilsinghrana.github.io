import { c as createComponent, m as maybeRenderHead, r as renderComponent, a as renderTemplate, b as renderHead } from '../chunks/astro/server_CxJSMMQf.mjs';
import { $ as $$Schema } from '../chunks/Schema_DPvfm28N.mjs';
/* empty css                                 */
import { $ as $$Image, a as aboutPageKeywords } from '../chunks/DescriptionMeta_zINpuFPu.mjs';
import { $ as $$SectionHeaderImage } from '../chunks/SectionHeaderImage_Co5sByf-.mjs';
import { m as moonFacts } from '../chunks/moonFacts_C-S_TFZY.mjs';
import { $ as $$Index } from '../chunks/index_BlVSAaEf.mjs';
export { renderers } from '../renderers.mjs';

const educationPlaceholder = new Proxy({"src":"/_astro/educationPlaceholder.DG6MYjFe.webp","width":1024,"height":1024,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/educationPlaceholder.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/educationPlaceholder.webp");
							return target[name];
						}
					});

const $$Education = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section id="education" class="education"> <h2>Education</h2> <div class="contentWrapper"> ${renderComponent($$result, "Image", $$Image, { "class": "aboutPageSectionImage", "src": educationPlaceholder, "alt": "companyHero" })} <ul> <li> <h4 id="Sigma"> <a href="https://sigmauniversity.ac.in/" target="_blank">Sigma Institute of Engineering</a> </h4> <p> <b><a href="https://www.gtu.ac.in/" target="_blank">(Gujarat Technological University)</a></b> </p> <p>Information Technology - Bachelor Of Engineering</p> </li> <li> <h4 id="Shreyas"> <a href="http://shreyas.edu.in/" target="_blank">Shreyas Vidhyalay</a> </h4> <p>Higher Secondary</p> </li> <li> <h4 id="BHS"> <a href="https://barodahighschool.com/" target="_blank">Baroda High School</a> </h4> <p>Secondary Education</p> </li> </ul> </div> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/Education.astro", void 0);

const WebDev = new Proxy({"src":"/_astro/web-dev3.B8Zbsuv_.webp","width":1024,"height":1024,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/web-dev3.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/web-dev3.webp");
							return target[name];
						}
					});

const $$Experience = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section id="experience" class="experience"> <h2>Professional Experience</h2> <div class="experienceInfoWrapper"> ${renderComponent($$result, "Image", $$Image, { "class": "companyLogo aboutPageSectionImage", "src": WebDev, "alt": "companyHero", "loading": "eager" })} <div class="experienceDetailsWrapper"> <div class="companyInfo"> <h3 id="WebmyneSystems"> <a href="https://www.webmyne.com/" target="_blank">Webmyne Systems</a> </h3> <span>Sr.Software Developer : July 2021 - Present</span> </div> <p class="companyDescription">
At Webmyne, I worked on various projects, primarily using React.js.
        Later, I joined Panamax Inc. as a consultant from Webmyne, contributing
        to the Mobifin project in the R&D department. I utilized technologies
        like React.js, Node.js, Next.js, Module Federation and MongoDB to
        maintain existing and develop new features for the fintech product.
</p> <section> <ul> <li class="projectInfo"> <h4 id="DocumentManagementSystem">
Document Management System(DMS)
</h4> <p>
Developed a client application (web) and an admin panel featuring
              multiple roles and permissions to facilitate document sharing
              between clients-firm employees or within the organization. The
              system included functionalities for work tracking/status updates,
              employee management, client management, and billing hours.
</p> </li> <li class="projectInfo"> <h4 id="RepositoryManagementSystem">
Repository Management System(RMS)
</h4> <p>Application for file sharing within an organization</p> </li> <li> <section id="Panamax" class="subExperienceWrapper"> <div class="companyInfo"> <h3 id="Panamax"> <a href="https://www.panamaxil.com/" target="_blank">Panamax. Inc.</a> </h3> <span>Consultant; March 2022-September 2025</span> </div> <div class="projectInfo"> <h4 id="MobifinElite"> <a href="https://www.mobifin.com/" target="_blank">Mobifin Elite</a> </h4> <p>
Worked on the web application, including both the CMS backend
                  and frontend, as well as the Backend for Frontend (BFF).
                  Maintained existing features and Integrated new features such
                  as Split Payment, Loyalty and Rewards, Standing Instructions,
                  Partial merchant refunds and Multipayment.
</p> <p>
- Worked on and initialized
<a href="https://www.mobifin.com/tapestry/" target="_blank" rel="noopener noreferrer">Mobin Tapestry</a>
from scratch.
</p> </div> </section> </li> </ul> </section> </div> </div> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/Experience.astro", void 0);

const otherActivitiesPlaceholder = new Proxy({"src":"/_astro/otherActivitiesPlaceholder.BETxo3s-.webp","width":1024,"height":1024,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/otherActivitiesPlaceholder.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/otherActivitiesPlaceholder.webp");
							return target[name];
						}
					});

const $$OtherActivities = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section id="otherActivities" class="otherActivities"> <h2 id="otherActivities">Other Activities</h2> <div class="contentWrapper"> ${renderComponent($$result, "Image", $$Image, { "class": "aboutPageSectionImage", "src": otherActivitiesPlaceholder, "alt": "companyHero" })} <ul> <li> <h4 id="BFA"> <a href="https://barodafootballacademy.co.in/" target="_blank">Baroda Football Academy</a> </h4> <p>
Played for and volunteered as a Football Coach, Social Media Head,
          Graphic Designer and Website Designer at Baroda Football Academy
</p> </li> <li> <h4 id="Football">Football</h4> <p>
I had the opportunity to captain both my college and school football
          teams, an experience I deeply cherished. Additionally, I had the
          privilege of representing Gujarat Technological University (GTU) at
          the All India University Football Tournament on multiple occasions.
</p> </li> <li> <h4 id="CoCurricular">Co-Curricular</h4> <p>
During my school days, I had the chance to take part in a variety of
          athletic events like the 100m, 400m, high jump, and long jump.
          Alongside sports, I also enjoyed engaging in activities such as
          debates, quiz competitions, and Olympiads.
</p> </li> </ul> </div> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/OtherActivities.astro", void 0);

const placeholderImage = new Proxy({"src":"/_astro/placeholder4comp.CUg5Sv7e.webp","width":450,"height":450,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder4comp.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder4comp.webp");
							return target[name];
						}
					});

const $$About = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`<head>${renderComponent($$result, "Schema", $$Schema, { "item": {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    dateCreated: "2024-06-11T12:34:00+05:30",
    dateModified: "2025-09-02T12:00:00+05:30",
    mainEntity: {
      "@type": "Person",
      name: "Sahil Rana",
      alternateName: ["Sahil Singh Rana", "sahilsinghrana"],
      identifier: "sahilsinghrana",
      jobTitle: "Sr. Software Developer",
      worksFor: {
        "@type": "Organization",
        name: "Webmyne Systems Pvt. Ltd.",
        url: "https://www.webmyne.com"
      },
      description: "Sahil Rana (also known as Sahil Singh Rana) is a software developer specializing in the MERN stack, JavaScript, and full-stack web development. He builds modern, scalable, and performance-driven applications.",
      image: "https://avatars.githubusercontent.com/u/48375250?v=4",
      url: "https://sahilrana.in",
      sameAs: [
        "https://sahilsinghrana.github.io",
        "https://www.sahilrana.in",
        "https://www.linkedin.com/in/sahilsinghrana",
        "https://x.com/sahilrana010",
        "https://instagram.com/sahilrana0_0",
        "https://github.com/sahilsinghrana"
      ],
      knowsAbout: [
        "MERN Stack",
        "JavaScript",
        "Node.js",
        "React.js",
        "Express.js",
        "MongoDB",
        "Full-Stack Development",
        "REST APIs",
        "Web Applications"
      ],
      alumniOf: {
        "@type": "CollegeOrUniversity",
        name: "Gujarat Technological University"
      }
    }
  } })}${renderHead()}</head> ${renderComponent($$result, "Layout", $$Index, { "title": "About | Sahil Rana | Software Developer", "description": "Explore my journey of as a budding software developer, as i share some of my personal insights and aspirations in the world of coding on this About page.", "keywords": aboutPageKeywords }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "SectionHeaderImage", $$SectionHeaderImage, { "title": "About", "Image": placeholderImage, "quote": moonFacts.makesEarthMoveAndTides.fact })} <div class="aboutPage"> ${renderComponent($$result2, "Experience", $$Experience, {})} ${renderComponent($$result2, "Education", $$Education, {})} ${renderComponent($$result2, "OtherActivities", $$OtherActivities, {})} </div> <div class="moonFact"> ${moonFacts.slowingEarthRotation.fact} </div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/about.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/about.astro";
const $$url = "/about.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$About,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
