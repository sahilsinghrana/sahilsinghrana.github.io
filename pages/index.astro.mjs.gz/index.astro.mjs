import { c as createComponent, d as createAstro, r as renderComponent, a as renderTemplate, m as maybeRenderHead, h as renderScript, f as addAttribute, F as Fragment, b as renderHead } from '../chunks/astro/server_CxJSMMQf.mjs';
import { $ as $$Schema } from '../chunks/Schema_DPvfm28N.mjs';
import { $ as $$Index$9 } from '../chunks/index_BlVSAaEf.mjs';
/* empty css                                 */
import { t as $$, $ as $$Image, u as $$Picture, l as links, d as $$Linkedin, v as homePageKeywords } from '../chunks/DescriptionMeta_zINpuFPu.mjs';
import 'clsx';
/* empty css                                 */
import { d as diziPlayerMeta, j as jsonViewerMeta } from '../chunks/projects_W7M3ymvk.mjs';
import { g as getCollection } from '../chunks/_astro_content_B0m7ztxN.mjs';
import { m as moonFacts } from '../chunks/moonFacts_C-S_TFZY.mjs';
import { c as curlRequestGeneratorPlaceholder } from '../chunks/curlRequestGeneratorPlaceholder_vQgHbI-g.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro$5 = createAstro("https://sahilrana.in");
const $$Copy = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$Copy;
  return renderTemplate`${renderComponent($$result, "Layout", $$, { "iconName": "copy", ...Astro2.props }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect> <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/node_modules/lucide-astro/dist/Copy.astro", void 0);

const $$Astro$4 = createAstro("https://sahilrana.in");
const $$Index$8 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$Index$8;
  const { text } = Astro2.props;
  return renderTemplate`${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/CodeBlock/Command/index.astro?astro&type=script&index=0&lang.ts")} ${maybeRenderHead()}<p${addAttribute("codeblock-command", "class")}> <code>${text}</code> <button id="copyBtn"${addAttribute(text, "data-value")} data-copying="false" type="button"> ${renderComponent($$result, "Copy", $$Copy, { "height": 20, "width": 20 })} </button> </p>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/CodeBlock/Command/index.astro", void 0);

const fluteImage$1 = new Proxy({"src":"/_astro/flutenobg (3).CEsK-ldW.png","width":500,"height":500,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/flutenobg (3).png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/flutenobg (3).png");
							return target[name];
						}
					});

const $$Astro$3 = createAstro("https://sahilrana.in");
const $$SubSectionImage = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$SubSectionImage;
  const {
    className = "",
    src,
    alt,
    height,
    width,
    widths,
    loading
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div id="profilePicContainer" class="profilePicContainer"> ${renderComponent($$result, "Image", $$Image, { "src": fluteImage$1, "alt": "FLutee", "class": "flutebg", "height": height + 150, "width": width + 150 })} ${renderComponent($$result, "Picture", $$Picture, { "formats": ["avif", "webp"], "widths": widths || [80, 450], "class": className, "src": src, "alt": alt, "height": height, "width": width, "loading": loading })} </div> ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/SubSectionImage.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/SubSectionImage.astro", void 0);

const $$MyHeading = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section id="about" class="heading"> ${renderComponent($$result, "SubSectionImage", $$SubSectionImage, { "className": "profileImage", "src": links.profilePic, "alt": "Sahil Rana", "height": 150, "width": 150 })} <div> <h1> <strong>Sahil Singh Rana</strong> </h1> <h2>Software Developer</h2> ${renderComponent($$result, "Command", $$Index$8, { "text": "npx namaste-sahil" })} <a${addAttribute(links.linkedin, "href")} target="_blank"> ${renderComponent($$result, "Linkedin", $$Linkedin, { "height": 10, "width": 10, "color": "white" })} Connect
</a> </div> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/MyHeading.astro", void 0);

const $$AboutDescription = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section id="intro" class="intro"> <p>
Hey there! 💫 I'm a Software Developer. Most of my professional experience
    is built on the web. When not coding, you'll probably catch me enjoying
    music, running, playing football, exploring tech, or hanging out with
    friends. If all else fails, I might be out curiously placing question marks
    to things that aren't even questions.
</p> <p><a href="/about">Discover more!</a></p> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/AboutDescription.astro", void 0);

const $$Astro$2 = createAstro("https://sahilrana.in");
const $$Pill = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Pill;
  const { text, link } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${link ? renderTemplate`${maybeRenderHead()}<a class="pill"${addAttribute(link ? "_blank" : "_self", "target")}${addAttribute(link || "#", "href")}>${text}</a>` : renderTemplate`<span class="pill">${text}</span>`}` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Pills/Pill.astro", void 0);

const $$Astro$1 = createAstro("https://sahilrana.in");
const $$PillList = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$PillList;
  const { title, pills = [], className = "" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section${addAttribute(title, "id")}${addAttribute(`pillSection ${className}`, "class")}> <h2>${title}</h2> <ul> ${pills.map((pill = []) => {
    const [text, link] = pill;
    return renderTemplate`<li> ${renderComponent($$result, "Pill", $$Pill, { "text": text, "link": link })} </li>`;
  })} </ul> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Pills/PillList.astro", void 0);

const $$SkillsAndHobbies = createComponent(($$result, $$props, $$slots) => {
  const skills = [
    ["Javascript", "https://www.java.com/en/"],
    ["Typescript", "https://www.typescriptlang.org/"],
    ["Python", "https://www.python.org/"],
    ["JAVA", "https://www.java.com/en/"],
    ["React.js", "https://react.dev/"],
    ["Next.js", "https://nextjs.org/"],
    ["Express.js", "https://expressjs.com/"],
    ["MongoDB", "https://www.mongodb.com/"]
  ];
  const hobbies = [
    ["Fading into music"],
    ["Staring Nature"],
    ["Navigating through tech"],
    ["Running with football"]
  ];
  return renderTemplate`${renderComponent($$result, "Fragment", Fragment, {}, { "default": ($$result2) => renderTemplate`${renderComponent($$result2, "PillList", $$PillList, { "title": "Tech I Understand", "className": "Skills", "pills": skills })}${renderComponent($$result2, "PillList", $$PillList, { "title": "Materials I am attached to", "className": "Hobbies", "pills": hobbies })}` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/SkillsAndHobbies.astro", void 0);

const $$Index$7 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section id="about" class="about"> ${renderComponent($$result, "Heading", $$MyHeading, {})} ${renderComponent($$result, "Info", $$AboutDescription, {})} ${renderComponent($$result, "SkillsAndHobbies", $$SkillsAndHobbies, {})} </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/index.astro", void 0);

const $$NowPlaying = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="nowPlaying"> <div class="trackVinyl" id="nowPlayingTrackVinyl"></div> <a class="spotifyLogoContainer" target="_blank"> ${renderComponent($$result, "Image", $$Image, { "src": "https://storage.googleapis.com/pr-newsroom-wp/1/2023/05/Spotify_Full_Logo_RGB_White.png", "alt": "spotify logo", "height": "17", "width": "62", "class": "spotifyLogo" })} </a> <div class="notPlaying" id="notPlayingWrap"> <p>Ears at rest....</p> </div> <div id="nowPlayingInfo" class="nowPlayingInfo displayNone"> <h3 class="heading">Now Playing</h3> <div> <h4><a id="nowPlayingTitle" href=""></a></h4> <h5 id="nowPlayingArtists"></h5> </div> </div> </div> ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Spotify/NowPlaying.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Spotify/NowPlaying.astro", void 0);

const $$TopArtists = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="topArtistsContainer"> <h3>Current Top Artists</h3> <ul class="cardContainer"></ul> </div>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Spotify/TopArtists.astro", void 0);

const $$TopTracks = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="topTracksContainer" id="topTracksContainer"> <h3>Current Top Tracks</h3> <ul id="topTracksListContainer" class="cardContainer"></ul> <span class="smallInfo">* Click on cover art for song preview.</span> </div>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Spotify/TopTracks.astro", void 0);

const $$Index$6 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section class="spotifyData"> ${renderComponent($$result, "NowPlaying", $$NowPlaying, {})} <div class="topTrackAndArtistContainer"> ${renderComponent($$result, "TopArtists", $$TopArtists, {})} ${renderComponent($$result, "TopTracks", $$TopTracks, {})} </div> </section> ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Spotify/index.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Spotify/index.astro", void 0);

const moonGanymede = new Proxy({"src":"/_astro/moonGanymede.byeXNQVj.jpg","width":225,"height":226,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/MoonInfo/moonGanymede.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/MoonInfo/moonGanymede.jpg");
							return target[name];
						}
					});

const $$CurrentMoonInfo = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section> <details open class="currentMoonInfo"> <summary>Moonfull insights</summary> <p id="moonInfo_moonEvent"> <b id="moonEventPrefix"></b> <b id="moonEventDate">...</b> <span id="moonEventEvent">A total eclipse is a cosmic test.</span> </p> <dl class="moonInfo"> <dd id="moonInfo_waxWane">Phase: <b>calculating...</b></dd> <dd id="moonInfo_phase">
Current Phase: <b>calculating...</b> </dd> <dd id="moonInfo_age">Age: <b>calculating...</b></dd> <dd id="moonInfo_agePercent">Age Percent: <b>calculating...</b></dd> </dl> <div class="moonPhaseContainer"> <img id="moonPhaseImage" width="32" height="32"${addAttribute(moonGanymede.src, "src")} alt="moonGanymede"> <canvas id="moonPhaseCanvas" width="32" height="32"></canvas> </div> </details> </section> ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/MoonInfo/CurrentMoonInfo.astro?astro&type=script&index=0&lang.ts")} ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/MoonInfo/CurrentMoonInfo.astro?astro&type=script&index=1&lang.ts")} ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/MoonInfo/CurrentMoonInfo.astro?astro&type=script&index=2&lang.ts")}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/MoonInfo/CurrentMoonInfo.astro", void 0);

const DiziPlayerPreview = new Proxy({"src":"/_astro/DiziPlayerPreview.OIzmJPNH.webp","width":1400,"height":1400,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/DiziPlayerPreview.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/DiziPlayerPreview.webp");
							return target[name];
						}
					});

const $$Index$5 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="diziplayerPreviewWrapper previewWrapper"> <div class="details"> <div class="info"> <h2 class="diziTitle">DiZi ${"  "}<span>PLAYER</span></h2> <p>
A music player that will turn your cloud storage into a personal
        streaming service.
</p> </div> ${renderComponent($$result, "Image", $$Image, { "src": DiziPlayerPreview, "alt": "dizi player preview", "class": "previewImage", "width": 300, "height": 300 })} </div> <div class="footer"> <p class="status"><span>Under Development</span></p> <ul class="links"> ${diziPlayerMeta.links.map((link) => {
    const { Icon, link: url, description } = link;
    return renderTemplate`<li> <a${addAttribute(description, "aria-label")}${addAttribute(url, "href")} target="_blank"> ${renderComponent($$result, "Icon", Icon, {})} </a> </li>`;
  })} </ul> </div> </div>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/CurrentlyBuilding/DiziplayerPreview/index.astro", void 0);

const $$Index$4 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="jsonViewerPreviewWrapper previewWrapper"> <div class="details"> <div class="info"> <h2 class="jsonViewerTitle"> <span><span class="glitch">JSON</span> Viewer</span> <span><span class="glitch">JSON</span> Viewer</span> <span><span class="glitch">JSON</span> Viewer</span> </h2> <p>
JSON viewer with dark and light mode. Later, Will be adding features
        like unstringify, an easy path selection, export to file.
</p> </div> ${renderComponent($$result, "Image", $$Image, { "src": jsonViewerMeta.logo, "alt": "JSON Player preview", "class": "previewImage", "width": 300, "height": 300 })} </div> <div class="footer"> <p class="status"><span>Under Development</span></p> <ul class="links"> ${jsonViewerMeta.links.map((link) => {
    const { Icon, link: url } = link;
    return renderTemplate`<li> <a${addAttribute(url, "aria-label")}${addAttribute(url, "href")} target="_blank"> ${renderComponent($$result, "Icon", Icon, {})} </a> </li>`;
  })} </ul> </div> </div>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/CurrentlyBuilding/JsonViewerPreview/index.astro", void 0);

const $$Index$3 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section class="currentlyBuildingWrapper"> <h2 class="title">Building right now!</h2> <div class="previews"> ${renderComponent($$result, "JsonViewerPreview", $$Index$4, {})} ${renderComponent($$result, "DiziplayerPreview", $$Index$5, {})} </div> <div class="footer"> <a href="projects" class="linkBtn">View More!</a> </div> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/CurrentlyBuilding/index.astro", void 0);

const $$Astro = createAstro("https://sahilrana.in");
const $$Index$2 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index$2;
  const { title, description, image, slug } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(slug, "href")} class="featuredPostCard"> ${renderComponent($$result, "Image", $$Image, { "src": image?.src ? image : image?.url, "alt": image?.alt || title, "width": 80, "height": 80 })} <div class="content"> <h3 class="title"${addAttribute(slug, "id")}>${title}</h3> <p class="description">${description}</p> <!-- {
      pubDate && (
        <div class="meta">
          <span>{formatDate(pubDate)}</span>
        </div>
      )
    } --> </div> </a>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/FeaturedCard/index.astro", void 0);

const $$Index$1 = createComponent(async ($$result, $$props, $$slots) => {
  const blogEntries = (await getCollection("blog", ({ data }) => !!data.featured)).sort(
    (a, b) => new Date(b.data.pubDate).getTime() - new Date(a.data.pubDate).getTime()
  );
  const snippetsEntries = await getCollection(
    "snippets",
    ({ data }) => !!data.featured
  );
  return renderTemplate`${maybeRenderHead()}<section class="featuredList"> <div class="headings"> <h2>Sometimes I write too!</h2> <a href="/blog">See More!</a> </div> <ul> ${blogEntries.map(async (post) => {
    const { title, description, image } = post.data;
    return renderTemplate`<li> ${renderComponent($$result, "FeaturedCard", $$Index$2, { "title": title, "description": description, "image": image, "slug": "/blog/posts/" + post.id })} </li>`;
  })} ${snippetsEntries.map(async (post) => {
    const { title, description, image } = post.data;
    return renderTemplate`<li> ${renderComponent($$result, "FeaturedCard", $$Index$2, { "title": title, "description": description, "image": image, "slug": "/blog/snippets/" + post.id })} </li>`;
  })} </ul> <div class="blogLinks"> <a class="linkBtn" href="/blog/posts">See more blog posts..</a> <a class="linkBtn" href="/blog/snippets">Check out code snippets..</a> </div> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/Blog/FeaturedList/index.astro", void 0);

const $$FeaturedTools = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section class="featuredList tools"> <div class="headings"> <h2>Handy Tools!</h2> <!-- <a href="/blog">See More!</a> --> </div> <ul> <li> ${renderComponent($$result, "FeaturedCard", $$Index$2, { "title": "cURL request maker", "description": "Form to generate cURL requests.", "image": curlRequestGeneratorPlaceholder, "slug": "/tools/curlRequestGenerator" })} </li> </ul> </section>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Tools/FeaturedTools.astro", void 0);

const fluteImage = new Proxy({"src":"/_astro/flutenobg (2).BsRe0BTr.png","width":500,"height":500,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/flutenobg (2).png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/About/flutenobg (2).png");
							return target[name];
						}
					});

const shivaBG = new Proxy({"src":"/_astro/shiva.J8D5XOfr.png","width":626,"height":358,"format":"avif"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/shiva.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/shiva.png");
							return target[name];
						}
					});

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`<head>${renderComponent($$result, "Schema", $$Schema, { "item": {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "Sahil Rana",
    alternateName: [
      "Sahil Singh Rana",
      "Sahil Portfolio",
      "Sahil Rana Portfolio",
      "SSR",
      "Sahil",
      "Rana"
    ],
    url: "https://sahilrana.in",
    image: "https://avatars.githubusercontent.com/u/48375250?v=4",
    description: "Official website of Sahil Rana, a MERN stack and JavaScript developer specializing in modern, scalable, and performance-driven web applications.",
    publisher: {
      "@type": "Person",
      name: "Sahil Rana",
      url: "https://sahilrana.in",
      image: "https://avatars.githubusercontent.com/u/48375250?v=4",
      sameAs: [
        "https://sahilsinghrana.github.io",
        "https://www.linkedin.com/in/sahilsinghrana",
        "https://x.com/sahilrana010",
        "https://github.com/sahilsinghrana",
        "https://instagram.com/sahilrana0_0"
      ]
    }
  } })}${renderHead()}</head> ${renderComponent($$result, "Layout", $$Index$9, { "title": "Sahil Rana | Software Developer", "description": "Welcome to my portfolio! I am a software engineer specializing in web development, with expertise in cutting-edge technologies like React.js, Node.js, and MongoDB. Explore my projects and skills to see how I can help bring your ideas to life!", "keywords": homePageKeywords, "className": "homePage" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "About", $$Index$7, {})} ${renderComponent($$result2, "CurrentMoonInfo", $$CurrentMoonInfo, {})} <div class="saggittariusLink" style="position: relative;"> <p>Interested in Sagittarius ?</p> <a href="/resources/constellations/sagittarius">Click Me!!</a> ${renderComponent($$result2, "Image", $$Image, { "src": fluteImage, "alt": "FLutee", "class": "flutebgcommand", "height": 150, "width": 150, "style": "position: absolute;transform: rotate(45deg);z-index: -1;top: -45px; opacity: 0.4; mix-blend-mode: lighten;" })} </div> ${renderComponent($$result2, "CurrentlyBuilding", $$Index$3, {})} <div id="shlokaWrapper" style="position: relative;"> <blockquote id="shlokaDevanagari"></blockquote> <q id="shlokaTranslation"></q> <p id="shlokaChapter"></p> ${renderComponent($$result2, "Image", $$Image, { "src": shivaBG, "id": "shlokaBG", "alt": "shiva" })} </div> ${renderComponent($$result2, "FeaturedTools", $$FeaturedTools, {})} ${renderComponent($$result2, "FeaturedBlogs", $$Index$1, {})} ${renderComponent($$result2, "Spotify", $$Index$6, {})} <div class="moonFact"> ${moonFacts.darkSide.fact} </div> ` })} ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/index.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/index.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
