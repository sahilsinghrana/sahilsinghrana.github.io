import { c as createComponent, m as maybeRenderHead, r as renderComponent, f as addAttribute, a as renderTemplate } from '../chunks/astro/server_CxJSMMQf.mjs';
import { $ as $$SectionHeaderImage } from '../chunks/SectionHeaderImage_Co5sByf-.mjs';
import { $ as $$Index$1 } from '../chunks/index_BlVSAaEf.mjs';
import { $ as $$Image, l as links, c as $$Github, d as $$Linkedin, e as $$Twitter, f as $$Instagram, g as contactPageKeyWords } from '../chunks/DescriptionMeta_zINpuFPu.mjs';
/* empty css                                   */
import { m as moonFacts } from '../chunks/moonFacts_C-S_TFZY.mjs';
export { renderers } from '../renderers.mjs';

const placeholderImage = new Proxy({"src":"/_astro/placeholder5comp.6PnsYW1U.webp","width":500,"height":500,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder5comp.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder5comp.webp");
							return target[name];
						}
					});

const Mooon = new Proxy({"src":"/_astro/moooon.cLhZNsUd.gif","width":388,"height":388,"format":"gif"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/BusinessCard/moooon.gif";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/BusinessCard/moooon.gif");
							return target[name];
						}
					});

const mailToQR = new Proxy({"src":"/_astro/mailtoQR.CNgmJWA9.webp","width":1015,"height":1015,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/mailtoQR.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/mailtoQR.webp");
							return target[name];
						}
					});

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="businessCard"> <div class="front"> ${renderComponent($$result, "Image", $$Image, { "loading": "eager", "src": Mooon, "alt": "card bg", "width": 310, "height": 70 })} <h3>Sahil Singh Rana</h3> <span>Software Developer</span> </div> <div class="back"> ${renderComponent($$result, "Image", $$Image, { "src": mailToQR, "alt": "mail qr code" })} <ul> <li> <a target="_blank"${addAttribute(links.github, "href")}> ${renderComponent($$result, "GithubIcon", $$Github, {})} @sahilsinghrana
</a> </li> <li> <a target="_blank"${addAttribute(links.linkedin, "href")}> ${renderComponent($$result, "Linkedin", $$Linkedin, {})} @sahilsinghrana
</a> </li> <li> <a target="_blank"${addAttribute(links.twitter, "href")}> ${renderComponent($$result, "Twitter", $$Twitter, {})} @sahilrana010
</a> </li> <li> <a target="_blank"${addAttribute(links.instagram, "href")}> ${renderComponent($$result, "Instagram", $$Instagram, {})} @sahilrana0_0
</a> </li> </ul> </div> </div>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/General/BusinessCard/index.astro", void 0);

const $$Contact = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Index$1, { "title": "Contact | Sahil Singh Rana | Software Developer | Sahil Rana", "description": "Wanna talk? Let's connect. Reach out to me through this Contact page.", "keywords": contactPageKeyWords }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "SectionHeaderImage", $$SectionHeaderImage, { "title": "Contact", "Image": placeholderImage, "quote": moonFacts.drifting.fact })} ${maybeRenderHead()}<div class="contactCardWrapper"> ${renderComponent($$result2, "BusinessCard", $$Index, {})} </div> <div class="contactMe"> <p class="mail">
Feel free to get in touch with me via email at <a href="mailto:ranasahil98@gmail.com">ranasahil98@gmail.com</a> </p> <div> <p>Alternatively, you can connect with me on:</p> <ul> <small> <li> ${renderComponent($$result2, "Linkedin", $$Linkedin, {})} Linkedin : <a target="_blank"${addAttribute(links.linkedin, "href")}>@sahilsinghrana</a> </li> <li> ${renderComponent($$result2, "Twitter", $$Twitter, {})} X : <a target="_blank"${addAttribute(links.twitter, "href")}>@sahilrana010</a> </li> <li> ${renderComponent($$result2, "Github", $$Github, {})} Github : <a target="_blank"${addAttribute(links.github, "href")}>@sahilsinghrana</a> </li> <li> ${renderComponent($$result2, "Instagram", $$Instagram, {})} Instagram : <a target="_blank"${addAttribute(links.instagram, "href")}>@sahilrana0_0</a> </li> </small> </ul> </div> </div> <div class="moonFact"> ${moonFacts.farSideTerrain.fact} </div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/contact.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/contact.astro";
const $$url = "/contact.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Contact,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
