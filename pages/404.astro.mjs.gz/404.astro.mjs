import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { $ as $$Index } from '../chunks/index_DNSR4qz0.mjs';
export { renderers } from '../renderers.mjs';

const $$404 = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Index, { "title": "404 Not Found", "description": "I believe you are lost. Lets get back to main site.", "keywords": [
    "Sahil Rana",
    "Software developer",
    "Coding journey",
    "Learning",
    "Growth",
    "Aspirations",
    "Experience",
    "Insights",
    "Passion",
    "Development career"
  ] }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div style="text-align: center; min-height:30vh;margin:15% auto;"> <h1 style="font-size: 3.5rem;">404</h1> <h2 style="font-weight: lighter;">
The resource you are looking for is not available or maybe you are lost
</h2> </div> <div class="moonFact">
The Moon helps stabilize Earth's tilt, influencing our climate.
</div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/404.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/404.astro";
const $$url = "/404.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$404,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
