import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { g as getCollection } from '../chunks/_astro_content_DzYYXVV3.mjs';
import { $ as $$SectionHeaderImage } from '../chunks/SectionHeaderImage_DLSGA4n0.mjs';
import { $ as $$Index$1 } from '../chunks/index_DNSR4qz0.mjs';
import { $ as $$PostCard } from '../chunks/PostCard_CRIaJlxE.mjs';
import { $ as $$Index$2 } from '../chunks/index_Dv03vPbn.mjs';
import { b as blogPageKeywords } from '../chunks/DescriptionMeta_BXu827no.mjs';
import { m as moonFacts } from '../chunks/moonFacts_C-S_TFZY.mjs';
export { renderers } from '../renderers.mjs';

const placeholderImage = new Proxy({"src":"/_astro/placeholder.BcZH-10h.webp","width":427,"height":320,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder.webp");
							return target[name];
						}
					});

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const blogEntries = await getCollection("blog");
  const snippetsEntries = await getCollection("snippets");
  return renderTemplate`${renderComponent($$result, "Layout", $$Index$1, { "title": "Blog | Sahil Singh Rana | Software Developer | Sahil Rana", "description": "Welcome to my blog homepage. I write random stuff!", "keywords": blogPageKeywords }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "SectionHeaderImage", $$SectionHeaderImage, { "title": "Blog", "Image": placeholderImage, "quote": moonFacts.darkSurface.fact })} ${maybeRenderHead()}<p class="pageDesc">
Welcome to the Blog! I write random stuff out here. Generally posts can be
    about the things I've learned so far, Code Snippets I want to refer later,
    something I feel to share with the world or maybe when creativity within is
    resurrected.
</p> <div style="display:flex; gap : 1rem; margin-top : 2rem; flex-wrap: wrap; justify-content: space-around;"> ${blogEntries.map(async (post) => {
    const { title, description, image, pubDate, author } = post.data;
    return renderTemplate`${renderComponent($$result2, "PostCard", $$PostCard, { "title": title, "description": description, "image": image, "pubDate": pubDate, "author": author, "slug": "/blog/posts/" + post.id })}`;
  })} </div> <div style="margin-top: 2em; background: #79787850; padding : 20px; border-radius:8px;"> <div style="display : flex; justify-content:space-between; align-items: center; font-size:1rem; width : 100%; margin-bottom : 1em;"> <h3 style="font-size:0.9rem">Snippets</h3> <a href="/blog/snippets" style="font-size:0.75rem; color : #d3d3d3bd;">View more
</a> </div> ${snippetsEntries.map(async (post) => {
    const { title, description, image } = post.data;
    return renderTemplate`${renderComponent($$result2, "SnippetCard", $$Index$2, { "title": title, "description": description, "image": image, "slug": post.id })}`;
  })} </div> <div class="moonFact"> ${moonFacts.maria.fact} </div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/index.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/index.astro";
const $$url = "/blog.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
