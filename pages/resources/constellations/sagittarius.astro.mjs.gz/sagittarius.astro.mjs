import { d as createAstro, c as createComponent, r as renderComponent, m as maybeRenderHead, f as addAttribute, e as renderSlot, g as renderTransition, a as renderTemplate, h as renderScript } from '../../../chunks/astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { H as Head, i as $$Index, j as $$DefaultMeta, k as $$GtagHeadScripts, m as $$OgMeta, n as $$DescriptionMeta, o as $$Title } from '../../../chunks/DescriptionMeta_BXu827no.mjs';
/* empty css                                             */
/* empty css                                             */
export { renderers } from '../../../renderers.mjs';

const $$Astro$1 = createAstro("https://sahilrana.in");
const $$ConstellationLayout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ConstellationLayout;
  const { title, description, keywords } = Astro2.props;
  return renderTemplate`<html lang="en"> ${renderComponent($$result, "Head", Head, {}, { "default": ($$result2) => renderTemplate`${renderComponent($$result2, "DefaultMeta", $$DefaultMeta, {})}${renderComponent($$result2, "GtagHeadScripts", $$GtagHeadScripts, {})}${renderComponent($$result2, "OgMeta", $$OgMeta, { "title": title, "description": description })}${renderComponent($$result2, "DescriptionMeta", $$DescriptionMeta, { "title": title, "description": description, "keywords": keywords })}<title>${title}</title>` })}${maybeRenderHead()}<body class="constellation-page"${addAttribute(renderTransition($$result, "247shffp"), "data-astro-transition-scope")}> ${renderSlot($$result, $$slots["default"])} ${renderComponent($$result, "Footer", $$Index, {})} </body></html>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/layouts/Constellation/ConstellationLayout.astro", "self");

const $$ConstellationHeader = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<header class="constellation-hero"> ${renderComponent($$result, "Title", $$Title, {})} ${renderSlot($$result, $$slots["default"])} </header>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/layouts/Constellation/ConstellationHeader.astro", void 0);

const $$Astro = createAstro("https://sahilrana.in");
const $$Sagittarius = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Sagittarius;
  return renderTemplate`${renderComponent($$result, "ConstellationLayout", $$ConstellationLayout, { "title": "Sagittarius - The Archer", "description": "Explore the Sagittarius constellation, its brightest stars, and the rich mythology behind it. Learn about its location in the night sky and fascinating facts.", "keywords": [
    "Sagittarius constellation",
    "Sagittarius stars",
    "Sagittarius mythology",
    "Sagittarius facts",
    "Sagittarius location",
    "Sagittarius deep sky objects",
    "Sagittarius nebulae",
    "Sagittarius galactic center",
    "Sagittarius star map",
    "Sagittarius astronomy",
    "Sagittarius zodiac",
    "Sagittarius archer",
    "Sagittarius celestial navigation",
    "Sagittarius star chart",
    "Sagittarius constellation guide"
  ] }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="constellation-starfield"></div> ${renderComponent($$result2, "ConstellationHeader", $$ConstellationHeader, { "class": "constellation-hero" }, { "default": ($$result3) => renderTemplate` <div class="constellation-container"> <svg class="constellation-svg" viewBox="0 0 500 500"> <!-- Sagittarius constellation stars --> <circle class="constellation-star" cx="150" cy="200" r="4" data-name="Kaus Australis"></circle> <circle class="constellation-star" cx="200" cy="180" r="3" data-name="Kaus Media"></circle> <circle class="constellation-star" cx="250" cy="160" r="3" data-name="Kaus Borealis"></circle> <circle class="constellation-star" cx="300" cy="220" r="3" data-name="Nunki"></circle> <circle class="constellation-star" cx="350" cy="240" r="3" data-name="Ascella"></circle> <circle class="constellation-star" cx="400" cy="200" r="3" data-name="Shaula"></circle> <circle class="constellation-star" cx="180" cy="280" r="3" data-name="Nash"></circle> <circle class="constellation-star" cx="320" cy="300" r="3" data-name="Albaldah"></circle> <!-- Constellation lines --> <g class="constellation-lines"> <line x1="150" y1="200" x2="200" y2="180"></line> <line x1="200" y1="180" x2="250" y2="160"></line> <line x1="200" y1="180" x2="300" y2="220"></line> <line x1="300" y1="220" x2="350" y2="240"></line> <line x1="350" y1="240" x2="400" y2="200"></line> <line x1="150" y1="200" x2="180" y2="280"></line> <line x1="300" y1="220" x2="320" y2="300"></line> </g> </svg> </div> <div class="constellation-hero-content"> <h1 class="constellation-title">SAGITTARIUS</h1> <p class="constellation-subtitle">The Archer • ♐</p> <div class="constellation-coordinates"> <span>RA: 19h 00m</span> <span>Dec: -25°</span> </div> <div class="constellation-interaction-hint"> <p>✨ Click the stars above to explore ✨</p> </div> </div> ` })} <main class="constellation-content"> <section class="constellation-fact-card"> <h2>The Galactic Center</h2> <p>
Sagittarius contains the center of our Milky Way galaxy, hidden behind
        dense clouds of cosmic dust. This supermassive black hole, Sagittarius
        A*, has a mass 4 million times that of our Sun.
</p> <div class="constellation-stat"> <span class="number">26,000</span> <span class="unit">light-years away</span> </div> </section> <section class="constellation-fact-card"> <h2>Brightest Star</h2> <p>
Kaus Australis (ε Sagittarii) shines as the constellation's brightest
        star, a blue giant 145 light-years away with a surface temperature of
        22,000K.
</p> <div class="constellation-stat"> <span class="number">1.85</span> <span class="unit">magnitude</span> </div> </section> <section class="constellation-fact-card"> <h2>Deep Sky Objects</h2> <p>
Home to stunning nebulae including the Lagoon, Trifid, and Eagle
        nebulae. Contains more Messier objects than any other constellation.
</p> <div class="constellation-stat"> <span class="number">15</span> <span class="unit">Messier objects</span> </div> </section> <section class="constellation-mythology"> <h2>The Centaur Archer</h2> <p>
In Greek mythology, Sagittarius represents Chiron, the wise centaur who
        taught heroes like Achilles and Jason. Unlike other centaurs, Chiron was
        noble and learned, skilled in medicine, music, and archery. When
        accidentally wounded by Heracles' poisoned arrow, the immortal Chiron
        chose to give up his immortality to end his suffering, and Zeus placed
        him among the stars.
</p> </section> <section class="constellation-nebula-showcase"> <h2>Famous Nebulae</h2> <div class="constellation-nebula-grid"> <div class="constellation-nebula-item"> <h3>Lagoon Nebula (M8)</h3> <p>
A giant interstellar cloud 4,100 light-years away, visible to the
            naked eye as a pink cloud-like patch.
</p> <span class="nebula-type">Emission Nebula</span> </div> <div class="constellation-nebula-item"> <h3>Trifid Nebula (M20)</h3> <p>
Named for its three dark lanes, this nebula combines emission,
            reflection, and dark nebula in one spectacular object.
</p> <span class="nebula-type">Combination Nebula</span> </div> <div class="constellation-nebula-item"> <h3>Eagle Nebula (M16)</h3> <p>
Famous for the "Pillars of Creation" - towering columns of gas and
            dust where new stars are born.
</p> <span class="nebula-type">Star-forming Region</span> </div> </div> </section> <section class="constellation-astronomical-facts"> <h2>Astronomical Facts & Scientific Evidence</h2> <div class="constellation-facts-grid"> <div class="constellation-fact-item"> <div class="fact-content"> <h3>🌌 Galactic Center Location</h3> <p>
Sagittarius A* (Sgr A*) is a supermassive black hole at the center
              of our galaxy, with a mass of 4.154 million solar masses.
</p> <a href="https://www.nasa.gov/mission_pages/chandra/news/astronomers-reveal-first-image-of-the-black-hole-at-the-heart-of-our-galaxy.html" target="_blank" class="scientific-reference">NASA - Sagittarius A* Discovery</a> </div> </div> <div class="constellation-fact-item"> <div class="fact-content"> <h3>⭐ Star Formation Region</h3> <p>
The constellation contains the most active star-forming regions in
              our galaxy, with over 100 known star-forming complexes.
</p> <a href="https://science.nasa.gov/astrophysics/focus-areas/how-do-stars-form-and-evolve" target="_blank" class="scientific-reference">NASA - Star Formation Science</a> </div> </div> <div class="constellation-fact-item"> <div class="fact-content"> <h3>🌟 Messier Catalog Record</h3> <p>
Sagittarius holds the record for most Messier objects (15),
              including famous nebulae like M8 (Lagoon) and M20 (Trifid).
</p> <a href="https://www.messier.seds.org/more/mw_sag.html" target="_blank" class="scientific-reference">SEDS - Messier Objects in Sagittarius</a> </div> </div> <div class="constellation-fact-item"> <div class="fact-content"> <h3>🔭 Radio Astronomy Breakthrough</h3> <p>
The first radio waves from space were detected from Sagittarius in
              1931 by Karl Jansky, founding radio astronomy.
</p> <a href="https://www.nrao.edu/whatisra/hist_jansky.shtml" target="_blank" class="scientific-reference">NRAO - Karl Jansky Discovery</a> </div> </div> <div class="constellation-fact-item"> <div class="fact-content"> <h3>🌠 Stellar Density</h3> <p>
The galactic center region has a stellar density 25 million times
              higher than in our solar neighborhood.
</p> <a href="https://www.eso.org/public/news/eso1835/" target="_blank" class="scientific-reference">ESO - Galactic Center Studies</a> </div> </div> <div class="constellation-fact-item"> <div class="fact-content"> <h3>🌌 Dark Matter Evidence</h3> <p>
Observations of stars orbiting Sgr A* provided crucial evidence
              for dark matter and general relativity predictions.
</p> <a href="https://www.nobelprize.org/prizes/physics/2020/summary/" target="_blank" class="scientific-reference">Nobel Prize - Black Hole Research</a> </div> </div> </div> </section> <section class="constellation-culture-section"> <h2>Vedic Astrology & Hindu Tradition</h2> <div class="constellation-culture-grid"> <div class="constellation-culture-item"> <h3>Dhanus Rashi (धनुष राशि)</h3> <p>
In Vedic astrology, Sagittarius is known as "Dhanus" meaning bow. It
            represents the archer's weapon and symbolizes aim, direction, and
            spiritual quest for higher knowledge.
</p> </div> <div class="constellation-culture-item"> <h3>Ruling Planet: Jupiter (Guru)</h3> <p>
Jupiter, known as "Brihaspati" or "Guru" in Sanskrit, governs
            Sagittarius. It represents wisdom, spirituality, teaching, and
            expansion of consciousness.
</p> </div> <div class="constellation-culture-item"> <h3>Nakshatra Association</h3> <p>
Contains parts of Mula, Purva Ashadha, and Uttara Ashadha
            nakshatras. Each nakshatra brings unique qualities of
            transformation, victory, and leadership.
</p> </div> <div class="constellation-culture-item"> <h3>Element: Fire (Agni)</h3> <p>
Sagittarius belongs to the fire element, representing passion,
            energy, and the burning desire for truth and spiritual
            enlightenment.
</p> </div> </div> </section> <section class="constellation-facts-section"> <h2>Vedic Astronomical Significance</h2> <div class="constellation-facts-list"> <div class="constellation-fact-item"> <span class="fact-icon">🏹</span> <div> <h3>Ishvara (Divine Archer)</h3> <p>
Represents the cosmic archer who shoots arrows of divine knowledge
              to dispel ignorance and guide souls toward moksha (liberation).
</p> </div> </div> <div class="constellation-fact-item"> <span class="fact-icon">🕉️</span> <div> <h3>Spiritual Direction</h3> <p>
The bow points toward the galactic center, symbolizing the soul's
              journey toward the cosmic source and ultimate truth.
</p> </div> </div> <div class="constellation-fact-item"> <span class="fact-icon">📿</span> <div> <h3>Guru's Blessing</h3> <p>
Jupiter's influence brings wisdom, righteousness (dharma), and the
              ability to guide others on their spiritual path.
</p> </div> </div> <div class="constellation-fact-item"> <span class="fact-icon">🌟</span> <div> <h3>Moksha Karaka</h3> <p>
In Jyotish, Sagittarius is associated with the 9th house of higher
              learning, philosophy, and spiritual liberation.
</p> </div> </div> </div> </section> <section class="constellation-section-full vedic-characteristics"> <h2>Vedic Characteristics & Qualities</h2> <div class="vedic-grid"> <div class="vedic-card positive"> <h3>Positive Traits (Sattvic)</h3> <ul> <li>• Dharmic (righteous) nature</li> <li>• Spiritual wisdom and intuition</li> <li>• Natural teaching abilities</li> <li>• Philosophical mindset</li> <li>• Optimistic and adventurous</li> <li>• Strong moral compass</li> </ul> </div> <div class="vedic-card challenges"> <h3>Challenges (Rajasic/Tamasic)</h3> <ul> <li>• Tendency toward dogmatism</li> <li>• Impatience with slower learners</li> <li>• Restlessness and wanderlust</li> <li>• Overconfidence in beliefs</li> <li>• Difficulty with routine tasks</li> <li>• Can be preachy or judgmental</li> </ul> </div> <div class="vedic-card spiritual"> <h3>Spiritual Significance</h3> <ul> <li>• Represents the seeker of truth</li> <li>• Connection to higher realms</li> <li>• Guardian of sacred knowledge</li> <li>• Bridge between human and divine</li> <li>• Symbol of spiritual evolution</li> <li>• Protector of dharmic principles</li> </ul> </div> </div> <div class="mantra-box"> <h3>Mantra & Sacred Connection</h3> <p class="mantra-text">"ॐ गुरवे नमः" (Om Gurave Namah)</p> <p class="mantra-desc">
This mantra honors Jupiter (Guru), the ruling planet of Sagittarius,
          invoking wisdom, guidance, and spiritual enlightenment. Chanting this
          mantra while observing Sagittarius is believed to enhance one's
          connection to higher knowledge and dharmic path.
</p> </div> </section> </main> ` })} ${renderScript($$result, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/resources/constellations/sagittarius.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/resources/constellations/sagittarius.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/resources/constellations/sagittarius.astro";
const $$url = "/resources/constellations/sagittarius.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Sagittarius,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
