import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_CxJSMMQf.mjs';
import { g as getCollection } from '../../chunks/_astro_content_B0m7ztxN.mjs';
import { $ as $$SectionHeaderImage } from '../../chunks/SectionHeaderImage_Co5sByf-.mjs';
import { $ as $$Index$1 } from '../../chunks/index_BlVSAaEf.mjs';
import { $ as $$PostCard } from '../../chunks/PostCard_B8g9SQRF.mjs';
import { p as postsPageKeywords } from '../../chunks/DescriptionMeta_zINpuFPu.mjs';
import { m as moonFacts } from '../../chunks/moonFacts_C-S_TFZY.mjs';
export { renderers } from '../../renderers.mjs';

const placeholderImage = new Proxy({"src":"/_astro/blogPostsPlaceholdercomp.BqeIOCD-.webp","width":350,"height":240,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/blogPostsPlaceholdercomp.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/blogPostsPlaceholdercomp.webp");
							return target[name];
						}
					});

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const blogEntries = await getCollection("blog");
  return renderTemplate`${renderComponent($$result, "Layout", $$Index$1, { "title": "Blog Posts | Sahil Singh Rana | Software Developer | Sahil Rana", "description": "Hey! here I am writing about random topics which i have learned along the way.", "keywords": postsPageKeywords }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "SectionHeaderImage", $$SectionHeaderImage, { "title": "Blog Posts", "Image": placeholderImage, "quote": moonFacts.moonQuakes.fact, "showBreadcrumbs": true })} ${maybeRenderHead()}<div style="display:flex; gap : 1.2rem; margin-top : 2rem; flex-wrap: wrap; justify-content: space-around;"> ${blogEntries.map(async (post) => {
    const { title, description, image, pubDate, author } = post.data;
    return renderTemplate`${renderComponent($$result2, "PostCard", $$PostCard, { "title": title, "description": description, "image": image, "pubDate": pubDate, "author": author, "slug": "/blog/posts/" + post.id })}`;
  })} </div> <div class="moonFact"> ${moonFacts.heavilyCratered.fact} </div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/posts/index.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/posts/index.astro";
const $$url = "/blog/posts.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
