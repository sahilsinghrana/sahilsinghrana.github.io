import { d as createAstro, c as createComponent, r as renderComponent, a as renderTemplate } from '../../../chunks/astro/server_CxJSMMQf.mjs';
import { $ as $$BlogPost, a as $$BlogPostContent } from '../../../chunks/BlogPostContent_DFpuUrQg.mjs';
import { r as renderEntry, g as getCollection } from '../../../chunks/_astro_content_B0m7ztxN.mjs';
export { renderers } from '../../../renderers.mjs';

const $$Astro = createAstro("https://sahilrana.in");
async function getStaticPaths() {
  const snippetEntries = await getCollection("snippets");
  return snippetEntries.map((entry) => ({
    params: { slug: entry.id },
    props: { entry }
  }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { entry } = Astro2.props;
  const { Content } = await renderEntry(entry);
  return renderTemplate`${renderComponent($$result, "BlogPost", $$BlogPost, { "entry": entry }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "BlogPostContent", $$BlogPostContent, {}, { "default": async ($$result3) => renderTemplate` ${renderComponent($$result3, "Content", Content, {})} ` })} ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/snippets/[slug].astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/snippets/[slug].astro";
const $$url = "/blog/snippets/[slug].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
