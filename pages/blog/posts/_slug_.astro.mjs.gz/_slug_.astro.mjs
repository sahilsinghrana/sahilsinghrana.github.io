import { d as createAstro, c as createComponent, r as renderComponent, a as renderTemplate } from '../../../chunks/astro/server_D_OWhRQa.mjs';
import 'piccolore';
import { $ as $$BlogPost, a as $$BlogPostContent } from '../../../chunks/BlogPostContent_Ck8gzzX8.mjs';
import { r as renderEntry, g as getCollection } from '../../../chunks/_astro_content_CloI7xJm.mjs';
export { renderers } from '../../../renderers.mjs';

const $$Astro = createAstro("https://sahilrana.in");
async function getStaticPaths() {
  const blogEntries = await getCollection("blog");
  return blogEntries.map((entry) => ({
    params: { slug: entry.id },
    props: { entry }
  }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { entry } = Astro2.props;
  const { Content } = await renderEntry(entry);
  return renderTemplate`${renderComponent($$result, "BlogPost", $$BlogPost, { "entry": entry }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "BlogPostContent", $$BlogPostContent, {}, { "default": async ($$result3) => renderTemplate` ${renderComponent($$result3, "Content", Content, {})} ` })} ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/posts/[slug].astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/posts/[slug].astro";
const $$url = "/blog/posts/[slug].html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
