import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_CxJSMMQf.mjs';
import { g as getCollection } from '../../chunks/_astro_content_B0m7ztxN.mjs';
import { $ as $$SectionHeaderImage } from '../../chunks/SectionHeaderImage_Co5sByf-.mjs';
import { $ as $$Index$1 } from '../../chunks/index_BlVSAaEf.mjs';
import { $ as $$Index$2 } from '../../chunks/index_DczveQdU.mjs';
import { s as snippetsPageKeywords } from '../../chunks/DescriptionMeta_zINpuFPu.mjs';
import { m as moonFacts } from '../../chunks/moonFacts_C-S_TFZY.mjs';
export { renderers } from '../../renderers.mjs';

const placeholderImage = new Proxy({"src":"/_astro/snippetsPlaceholder.B0PTADTC.webp","width":480,"height":360,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/snippetsPlaceholder.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/snippetsPlaceholder.webp");
							return target[name];
						}
					});

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const snippetsEntries = await getCollection("snippets");
  return renderTemplate`${renderComponent($$result, "Layout", $$Index$1, { "title": "Code Snippets | Sahil Singh Rana | Software Developer | Sahil Rana", "description": "I post code small code snippets here.", "keywords": snippetsPageKeywords }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "SectionHeaderImage", $$SectionHeaderImage, { "title": "Code Snippets", "Image": placeholderImage, "quote": moonFacts.makingOfMoon.fact, "showBreadcrumbs": true })} ${maybeRenderHead()}<div style="margin-top:3em; min-height: 40vh;"> ${snippetsEntries.map(async (post) => {
    const { title, description, image } = post.data;
    return renderTemplate`${renderComponent($$result2, "SnippetCard", $$Index$2, { "title": title, "description": description, "image": image, "slug": post.id })}`;
  })} </div> <div class="moonFact"> ${moonFacts.lunarCycleInfluence.fact} </div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/snippets/index.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/blog/snippets/index.astro";
const $$url = "/blog/snippets.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
