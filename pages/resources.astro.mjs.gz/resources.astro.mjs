import { d as createAstro, c as createComponent, m as maybeRenderHead, f as addAttribute, a as renderTemplate, r as renderComponent } from '../chunks/astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { $ as $$SectionHeaderImage } from '../chunks/SectionHeaderImage_DLSGA4n0.mjs';
import { $ as $$Index$1 } from '../chunks/index_DNSR4qz0.mjs';
import { r as resourcesPageKeywords } from '../chunks/DescriptionMeta_BXu827no.mjs';
import { m as moonFacts } from '../chunks/moonFacts_C-S_TFZY.mjs';
/* empty css                                 */
import 'clsx';
export { renderers } from '../renderers.mjs';

const placeholderImage = new Proxy({"src":"/_astro/resourcesPlaceholder.19D51ciW.webp","width":480,"height":270,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/resourcesPlaceholder.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/resourcesPlaceholder.webp");
							return target[name];
						}
					});

const $$Astro = createAstro("https://sahilrana.in");
const $$RefLink = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$RefLink;
  const { url = "", text = "ref" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<sup class="reflink" data-astro-cid-iambyadb>
[
<a target="_blank"${addAttribute(url, "href")} data-astro-cid-iambyadb> ${text} </a>
]
</sup>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Links/RefLink.astro", void 0);

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Index$1, { "title": "Resources | Sahil Singh Rana | Software Developer | Sahil Rana", "description": "Moon Resources and amazing facts about the moon", "keywords": resourcesPageKeywords }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "SectionHeaderImage", $$SectionHeaderImage, { "title": "Resources", "Image": placeholderImage })} ${maybeRenderHead()}<div class="resourcesMoonFactsWrapper"> <h2>Amazing facts about the moon</h2> <ul class="list"> ${Object.values(moonFacts).map((moonFact) => {
    return renderTemplate`<li class="factWrapper"> <p class="factTitle"> <span class="factWithIconBullet"> <span> ${moonFact.fact} ${!!moonFact.reference && renderTemplate`${renderComponent($$result2, "RefLink", $$RefLink, { "url": moonFact.reference })}`} </span> </span> </p> <p class="factDescription"> ${moonFact.description} ${!!moonFact.descriptionRef && renderTemplate`${renderComponent($$result2, "RefLink", $$RefLink, { "url": moonFact.descriptionRef })}`} </p> </li>`;
  })} </ul> </div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/resources/index.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/resources/index.astro";
const $$url = "/resources.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
