import { d as createAstro, c as createComponent, m as maybeRenderHead, r as renderComponent, f as addAttribute, a as renderTemplate } from '../chunks/astro/server_BPDaVsCp.mjs';
import 'piccolore';
import { $ as $$SectionHeaderImage } from '../chunks/SectionHeaderImage_DLSGA4n0.mjs';
import { $ as $$Index } from '../chunks/index_DNSR4qz0.mjs';
/* empty css                                    */
import { $ as $$Image, h as projectsPageKeywords } from '../chunks/DescriptionMeta_BXu827no.mjs';
import { p as projects } from '../chunks/projects_ClY54aPP.mjs';
import { m as moonFacts } from '../chunks/moonFacts_C-S_TFZY.mjs';
export { renderers } from '../renderers.mjs';

const RubiksCube = new Proxy({"src":"/_astro/rubikscube.BBJjkv_0.webp","width":728,"height":485,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/rubikscube.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/rubikscube.webp");
							return target[name];
						}
					});

const $$Astro = createAstro("https://sahilrana.in");
const $$ProjectCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ProjectCard;
  const { title, content, image, links } = Astro2.props;
  const displayImage = image || RubiksCube;
  return renderTemplate`${maybeRenderHead()}<div class="projectCard"> ${renderComponent($$result, "Image", $$Image, { "class": "projectCardImg", "src": displayImage, "alt": title, "width": 410, "height": 150 })} <div class="content"> <h2>${title}</h2> <p>${content}</p> </div> <ul class="links"> ${links.map(({ Icon, link }) => {
    if (!Icon) return null;
    return renderTemplate`<li> <a${addAttribute(link, "aria-label")}${addAttribute(link, "href")} target="_blank"> ${renderComponent($$result, "Icon", Icon, {})} </a> </li>`;
  })} </ul> </div>`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/components/Projects/ProjectCard.astro", void 0);

const placeholderImage = new Proxy({"src":"/_astro/placeholder3.D7NLvYds.webp","width":343,"height":480,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder3.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/assets/images/placeholder3.webp");
							return target[name];
						}
					});

const $$Projects = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Index, { "title": "Projects | Sahil Rana | Software Developer", "description": "Explore the collection of projects by Sahil Rana, offering a glimpse into his journey as a software developer.", "keywords": projectsPageKeywords }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "SectionHeaderImage", $$SectionHeaderImage, { "title": "Projects", "Image": placeholderImage, "quote": moonFacts.noMoonsOfMoon.fact })} ${maybeRenderHead()}<div class="projectList"> ${projects.map((project) => renderTemplate`${renderComponent($$result2, "ProjectCard", $$ProjectCard, { "title": project.title, "content": project.content, "links": project.links, "image": project.image })}`)} </div> <div class="moonFact"> ${moonFacts.largerAtHorizon.fact} </div> ` })}`;
}, "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/projects.astro", void 0);

const $$file = "/home/runner/work/sahilsinghrana.github.io/sahilsinghrana.github.io/src/pages/projects.astro";
const $$url = "/projects.html";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Projects,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
